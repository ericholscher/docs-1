!!! danger "Ensure a secure setup"

    Protect administrator access according to
    your organization's policy.

    @if deployment = self-hosted

        During [deployment], configure authentication
        before connecting production services.

    @if authentication = local

        Store local administrator credentials in
        your approved secret store.

[deployment]: ../../docs/deployment.md