# Acme Platform deployment guide

This is a small Zensical project for exploring variant-aware documentation with
[Zensical Studio](https://zensical.org/studio). It contains a deployment guide
that supports three deliverables:


- `cloud` — cloud deployment with single sign-on;
- `self-hosted` — self-hosted deployment with local authentication; and
- `self-hosted-sso` — self-hosted deployment with single sign-on.

The default variant is `cloud`.

## Open the project

1. Extract the archive.
2. Open the `deployment-guide` folder in VS Code.
3. Use [Zensical Studio](https://zensical.org/studio) to preview the
   pages in the project.

## Build with the Directives extension

The Directives extension is available as a preview in
[Zensical Spark](https://zensical.org/spark) and is ready to use today.
We'll continue to iterate on it before making it generally available. If your
team maintains shared content across products, versions, or audiences, we'd
value your feedback. You can explore our example project within Zensical Studio
(see below).

With the extension installed, building the default variant is as easy as
`zensical build`. To build another variant, use:

```console
ZENSICAL_VARIANT=self-hosted-sso zensical build --clean
```
