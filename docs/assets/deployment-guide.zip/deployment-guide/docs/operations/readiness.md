# Before you go live

Use this page as a final check before people start
using the platform.

## Security

@use shared/authentication-overview.md

## Quick go-live checklist

- Confirm who owns support during the first week.
- Confirm where users should report sign-in problems.
- Confirm where the team can check system status.

@if deployment = self-hosted

    ### Extra checks for self-hosted

    - Confirm a recent host backup exists.
    - Confirm someone can restore that backup.

@if authentication = single-sign-on

    ### Extra checks for single sign-on

    - Confirm users can sign in through your identity provider.

@elif authentication = local

    ### Extra checks for local authentication

    - Confirm the admin password reset process is documented.
