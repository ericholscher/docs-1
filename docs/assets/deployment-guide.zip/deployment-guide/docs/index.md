# Acme Platform deployment guide

Acme Platform connects internal services, operators, and identity providers
through one managed control plane. This **@var{deployment}** deployment uses
**@var{authentication}** authentication for administrator access.

@use shared/guide-introduction.md

## Choose a task

- Read [Deploy Acme Platform](deployment.md) to prepare the environment.
- Read [Configure authentication](authentication.md) to control access.
- Read [Before you go live](operations/readiness.md) for a final launch-day
  checklist.

Use these topics to prepare the environment, install the service where needed, and set up secure administrator access.
