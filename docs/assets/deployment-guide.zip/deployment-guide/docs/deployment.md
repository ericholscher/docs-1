# Deploy Acme Platform

@if deployment = cloud

    ## Set up the cloud deployment

    Create an Acme Platform workspace, then invite
    the operators who will configure the service.
    The service is managed for you. Continue to
    [configure authentication](authentication.md).

@elif deployment = self-hosted

    ## Set up the self-hosted deployment

    Provision a Linux host with network access to
    your identity provider and the package repository
    that provides Acme Platform. Download the server
    package and run the installer. It writes the
    service configuration to `/etc/acme-platform/`.

## Continue configuration

@use shared/deployment-overview.md
